package ruanko.newspublish.biz;

import ruanko.newspublish.dao.Newsdao;
import ruanko.newspublish.entity.News;

import java.util.List;

public class NewsBiz {

    private Newsdao newsDao;

    public NewsBiz() {
        this.newsDao = new Newsdao();
    }
    /**
     * 添加
     */
    public void add(News news) {
        newsDao.addNews(news);
    }

    /**
     * 删除
     */
    public void delete(int news_no) {
        newsDao.deleteNews(news_no);
    }

    /**
     * 更新
     */
    public void update(News news) {
        newsDao.updateNewsInfo(news);
    }

    /**
     * 得到一篇新闻（action层点击新闻进入详情时show）
     */
    public News get(int news_no) {return newsDao.get(news_no);}
    public News getN(int news_no){return newsDao.getN(news_no);}
    public News getall(int news_no){return newsDao.getall(news_no);}
    public void hitsup(News news){newsDao.hitsup(news);}

    /**
     * 查找新闻，满足的新闻应该是一个列表展示
     */
    public List<News> search(String keyword) {return newsDao.searchNews(keyword);}

    /**
     * 查找所有新闻
     */
    public List<News> getAll(){return newsDao.getAll();}

    /**
     * 得到栏目所有新闻（action层进入栏目时显示show）
     */
    public List<News> getType(String news_type){return newsDao.gettype(news_type);}
    /**
     * 得到最新新闻（action层进入最新时显示show）
     */
    public List<News> getTime(){return newsDao.gettime();}
    /**
     * 得到最热新闻（action层进入最热时显示show）
     */
    public List<News> getClick(){
        return newsDao.getclick();
    }
    /**
     * 得到我的新闻（action层进入我的时显示show）
     */
    public List<News> getMynews(int user_id){
        return newsDao.getmynews(user_id);
    }
    /**
     * 得到管理员审核的新闻（action层进入审核时显示show）
     */
    public List<News> getCheck(){return newsDao.getcheck();}

    public void checknewsY(News news){newsDao.checknewsy(news);}
    public void checknewsN(int news_no){newsDao.checknewsn(news_no);}
}
