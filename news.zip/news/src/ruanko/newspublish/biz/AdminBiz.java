package ruanko.newspublish.biz;

import ruanko.newspublish.dao.Admindao;
import ruanko.newspublish.entity.Admin;

public class AdminBiz {
    /**
     * 管理员
     */
    private Admindao adminDao;

    public AdminBiz() {
        this.adminDao = new Admindao();
    }

    public Admin adminLogin(Admin admin) {return adminDao.get(admin);}


}
