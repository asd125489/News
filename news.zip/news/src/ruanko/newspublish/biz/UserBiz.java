package ruanko.newspublish.biz;
import ruanko.newspublish.dao.*;
import ruanko.newspublish.entity.*;
import java.util.List;

/**
 * 用户业务逻辑<br>
 * 一般来说，我只将具体的操作交由具体的功能类来完成，
 * 比如，需要操作数据库了，就让dao类去做<br>
 * 这时候好多人认为业务逻辑类的存在是没有必要的，
 * 上层的servlet完全可以直接调用dao类去进行数据库操作<br>
 *
 * 业务逻辑层有利于系统的维护与扩展
 *
 */
public class UserBiz {
    /**
     * 用户
     */
    private Userdao userdao;
    public UserBiz() {
        this.userdao = new Userdao();
    }
    public User get(int user_id) {return userdao.get(user_id);}
    public List<User> ShowAll(){return userdao.ShowAll();}
    public User Test(User user) {return userdao.test(user);}
    public void userRegister(User user){userdao.addUser(user);}
    public User userLogin(User user) {
        return userdao.searchSingleUser(user);
    }
    public void changeInfo(User user){userdao.updateInfoUser(user);}
    public void userDelete(int user_id){userdao.deleteUser(user_id);}
}

