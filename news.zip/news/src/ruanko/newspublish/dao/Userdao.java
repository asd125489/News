package ruanko.newspublish.dao;


import ruanko.newspublish.action.AESUtil;
import ruanko.newspublish.entity.News;
import ruanko.newspublish.entity.User;


import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Userdao extends Basedao{
    AESUtil AES = new AESUtil();

    public User get(int user_id){
        String sql = "SELECT * FROM user WHERE user_id=" + user_id;
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("user_id"));
                user.setPassword(resultSet.getString("user_password"));
                user.setName(resultSet.getString("user_name"));
                user.setGender(resultSet.getString("gender"));
                user.setAge(resultSet.getInt("age"));
                user.setSignature(resultSet.getString("user_signature"));

                closeAll(connection, statement, resultSet);
                return user;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    /**
     * 检测该用户名是否已存在
     *
     * @param user
     * @return
     */
    public User test(User user) {

        String sql = "SELECT * FROM user WHERE user_name='" + user.getName() + "'";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                User user1 = new User();
                user1.setId(resultSet.getInt("user_id"));
                user1.setName(resultSet.getString("user_name"));
                user1.setGender(resultSet.getString("gender"));
                user1.setAge(resultSet.getInt("age"));
                user1.setSignature(resultSet.getString("user_signature"));
                closeAll(connection, statement, resultSet);
                return user1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public User searchSingleUser(User user) {

        String sql = "SELECT * FROM user WHERE user_name='" + user.getName() + "' AND user_password='" + AES.encrypt(user.getPassword(), "adminadmin123456") + "'";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                User user1 = new User();
                user1.setId(resultSet.getInt("user_id"));
                user1.setName(resultSet.getString("user_name"));
                user1.setPassword(resultSet.getString("user_password"));
                user1.setGender(resultSet.getString("gender"));
                user1.setAge(resultSet.getInt("age"));
                user1.setSignature(resultSet.getString("user_signature"));
                closeAll(connection, statement, resultSet);
                return user1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void updateInfoUser(User user){
        String sql = "UPDATE user SET user_name='" +
                user.getName() +
                "', user_password='" +
                user.getPassword() +
                "', gender='" +
                user.getGender() +
                "', age='" +
                user.getAge() +
                "', user_signature='" +
                user.getSignature() +
                "' WHERE user_id=" + user.getId();
        executeUpdate(sql);
    }

    public void deleteUser(int user_id){
        String sql = "DELETE FROM user WHERE user_id=" + user_id;
        executeUpdate(sql);
    }

    public void addUser(User user){
        String sql = "INSERT INTO user(user_id, user_password, user_name, gender, age, user_signature) VALUES('" +
                user.getId() +
                "','" +
                AES.encrypt(user.getPassword(), "adminadmin123456") +
                "','" +
                user.getName() +
                "','" +
                user.getGender() +
                "','" +
                user.getAge() +
                "','" +
                user.getSignature() +
                "')";
        executeUpdate(sql);
    }

    public List<User> ShowAll(){
        List<User> users;
        String sql = "SELECT * FROM user";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            users = new ArrayList<User>();
            while (resultSet.next()) {
                User user = new User();
                user.setId(resultSet.getInt("user_id"));
                user.setPassword(resultSet.getString("user_password"));
                user.setName(resultSet.getString("user_name"));
                user.setGender(resultSet.getString("gender"));
                user.setAge(resultSet.getInt("age"));
                user.setSignature(resultSet.getString("user_signature"));
                users.add(user);
                // System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return users;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
