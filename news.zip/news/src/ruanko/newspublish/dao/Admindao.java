package ruanko.newspublish.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import ruanko.newspublish.action.AESUtil;
import ruanko.newspublish.entity.Admin;
import ruanko.newspublish.entity.User;

public class Admindao extends Basedao{
    AESUtil AESA= new AESUtil();
    /**
     * 管理员查询
     *
     * @param
     * @return 管理员
     */
    public Admin get(Admin admin) {
        String sql = "SELECT * FROM admin WHERE admin_name='" + admin.getName()+"' AND admin_password='"+AESA.encrypt(admin.getPassword(), "adminadmin123456") +"'";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                Admin admin1 = new Admin();
                admin1.setId(resultSet.getInt("admin_id"));
                admin1.setName(resultSet.getString("admin_name"));
                admin1.setPassword(resultSet.getString("admin_password"));

                closeAll(connection, statement, resultSet);
                return admin1;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
}
