package ruanko.newspublish.dao;

import ruanko.newspublish.entity.News;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

public class Newsdao extends Basedao{
    public void addNews(News news){
        String sql = "INSERT INTO news(news_no, news_type, title, author_id, news_content, hits, create_time, update_time, flag) VALUES(" +
                "NULL,'" +
                news.getNewsType() +
                "','" +
                news.getTitle() +
                "','" +
                news.getAuthorId() +
                "','" +
                news.getContent() +
                "'," +
                "0,'" +
                news.getCreateTime() +
                "','" +
                news.getUpdateTime() +
                "'," +
                "0" +
                ")";
        executeUpdate(sql);
    }

    public void deleteNews(int news_no){
        String sql = "DELETE FROM news WHERE news_no=" + news_no;
        executeUpdate(sql);
    }

    public void updateNewsInfo(News news){
        String sql = "UPDATE news SET news_type='" +
                news.getNewsType() +
                "', title='" +
                news.getTitle() +
                "', author_id='" +
                news.getAuthorId() +
                "', news_content='" +
                news.getContent() +
                "', hits='" +
                news.getHits() +
                "', create_time='" +
                news.getCreateTime() +
                "', update_time='" +
                news.getUpdateTime() +
                "', flag='" +
                news.getFlag() +
                "' WHERE news_no=" + news.getNo();
        executeUpdate(sql);
    }

    public News get(int news_no){
        String sql = "SELECT * FROM news WHERE flag=1 AND news_no=" + news_no;
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setNewsType(resultSet.getString("news_type"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setContent(resultSet.getString("news_content"));
                news.setHits(resultSet.getInt("hits"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setFlag(resultSet.getInt("flag"));

                closeAll(connection, statement, resultSet);
                return news;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }
    public News getN(int news_no){
        String sql = "SELECT * FROM news WHERE flag=0 AND news_no=" + news_no;
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setNewsType(resultSet.getString("news_type"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setContent(resultSet.getString("news_content"));
                news.setHits(resultSet.getInt("hits"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setFlag(resultSet.getInt("flag"));

                closeAll(connection, statement, resultSet);
                return news;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public News getall(int news_no){
        String sql = "SELECT * FROM news WHERE  news_no=" + news_no;
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            if (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setNewsType(resultSet.getString("news_type"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setContent(resultSet.getString("news_content"));
                news.setHits(resultSet.getInt("hits"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setFlag(resultSet.getInt("flag"));

                closeAll(connection, statement, resultSet);
                return news;
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> getAll(){
        List<News> newss;
        String sql = "SELECT * FROM news ";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                newss.add(news);
                // System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> searchNews(String keyword){
        List<News> newss;
        String sql = "SELECT * FROM news WHERE title LIKE '%"+keyword+"%' AND flag=1";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                newss.add(news);
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> gettype(String news_type){
        List<News> newss;
        String sql = "SELECT * FROM news WHERE flag=1 AND news_type ='"+news_type+"'";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                newss.add(news);
                // System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> gettime(){
        List<News> newss;
        String sql = "SELECT * FROM news WHERE flag=1 ORDER BY create_time DESC LIMIT 20";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                newss.add(news);
                // System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> getclick(){
        List<News> newss;
        String sql = "SELECT * FROM news WHERE flag=1 AND hits>100";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setNewsType(resultSet.getString("news_type"));
                news.setHits(resultSet.getInt("hits"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                news.setFlag(resultSet.getInt("flag"));
                newss.add(news);
                //System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> getmynews(int user_id){
        List<News> newss;
        String sql = "SELECT * FROM news WHERE flag=1 AND author_id =" + user_id;
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                newss.add(news);
                // System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public List<News> getcheck(){
        List<News> newss;
        String sql = "SELECT * FROM news WHERE flag=0";
        Connection connection = getConnection();
        Statement statement;
        try {
            statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery(sql);
            newss = new ArrayList<News>();
            while (resultSet.next()) {
                News news = new News();
                news.setNo(resultSet.getInt("news_no"));
                news.setTitle(resultSet.getString("title"));
                news.setAuthorId(resultSet.getInt("author_id"));
                news.setCreateTime(resultSet.getString("create_time"));
                news.setUpdateTime(resultSet.getString("update_time"));
                news.setContent(resultSet.getString("news_content"));
                newss.add(news);
                // System.out.println(news.getTitle());
            }
            closeAll(connection, statement, resultSet);
            return newss;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }

    public void hitsup(News news){
        String sql = "UPDATE news SET hits=hits+1 WHERE news_no=" + news.getNo();
        executeUpdate(sql);
    }

    public  void checknewsy(News news){
        String sql = "UPDATE news SET flag=1 WHERE news_no=" + news.getNo();
        executeUpdate(sql);
    }

    public  void checknewsn(int news_no){
        String sql = "DELETE FROM news WHERE news_no=" + news_no;
        executeUpdate(sql);
    }
}


