package ruanko.newspublish.action.admin;

import ruanko.newspublish.biz.AdminBiz;
import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.Admin;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;




/**
 * 管理员登录
 *
 */
public class AdminLogin extends HttpServlet {

    private static final long serialVersionUID = 380840365327641661L;

    /**
     * 只处理post方式<br>
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf8");
        //输入管理员账号密码
        String admin_name = request.getParameter("admin_name");
        String admin_password = request.getParameter("admin_password");
        Admin admin=new Admin();
        admin.setName(admin_name);
        admin.setPassword(admin_password);

        //创建业务逻辑对象获取该新闻
        AdminBiz adminBiz = new AdminBiz();
        Admin admin1 = adminBiz.adminLogin(admin);

        if(admin1==null){
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter pw=response.getWriter();
            pw.print("<script language='javascript'>alert('用户名或密码错误');window.location.href='adminlogin.jsp';</script>");
            /**
             * 显示错误的系统弹窗（不好看 是浏览器自带的弹窗）
             **/
            //request.getRequestDispatcher("adminlogin.jsp").forward(request, response);
        }else {
            //跳转到主页面
            request.getRequestDispatcher("houtai.jsp").forward(request, response);
        }

    }

}
