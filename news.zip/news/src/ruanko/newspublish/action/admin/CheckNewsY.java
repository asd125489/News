package ruanko.newspublish.action.admin;

import ruanko.newspublish.biz.AdminBiz;
import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * 审核 一篇 新闻，通过
 */
public class CheckNewsY extends HttpServlet {

    private static final long serialVersionUID = -158250577084126706L;

    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        //得到要审核新闻的no
        int news_no = Integer.parseInt(request.getParameter("news_no"));


        //创建业务逻辑对象，并取得该新闻
        NewsBiz newsBiz = new NewsBiz();
        News news = newsBiz.getN(news_no);

        //新闻通过审核，flag改为1
        newsBiz.checknewsY(news);

        //跳转到审核新闻的列表页面
        request.getRequestDispatcher("houtai.jsp").forward(request, response);
    }
}
