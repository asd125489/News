package ruanko.newspublish.action.admin;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * 管理员退出，返回管理员登录
 */
public class AdminQuit extends HttpServlet {

    private static final long serialVersionUID = -1951259619173261540L;

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("adminlogin.jsp").forward(request, response);
    }
}
