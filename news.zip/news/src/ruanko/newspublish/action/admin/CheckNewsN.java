package ruanko.newspublish.action.admin;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.biz.AdminBiz;
import ruanko.newspublish.biz.NewsBiz;


/**
 * 审核 一篇 新闻，未通过
 *
 */
public class CheckNewsN extends HttpServlet {


    private static final long serialVersionUID = 5377819019584366417L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //得到要删除新闻的no
        int news_no = Integer.parseInt(request.getParameter("news_no"));

        //创建业务逻辑对象，未通过即删除该新闻
        NewsBiz newsBiz = new NewsBiz();

        newsBiz.checknewsN(news_no);

        //跳转到审核新闻的列表页
        request.getRequestDispatcher("houtai.jsp").forward(request, response);

    }
}
