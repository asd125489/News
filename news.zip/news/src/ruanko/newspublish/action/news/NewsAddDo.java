package ruanko.newspublish.action.news;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.News;
import ruanko.newspublish.entity.User;



/**
 * 执行添加操作
 *
 */
public class NewsAddDo extends HttpServlet {


    private static final long serialVersionUID = 2779579638766820689L;

    /**
     * 只允许post方式添加
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //解决中文乱码问题，这取决于前台jsp页面上设置的编码格式
        request.setCharacterEncoding("utf8");

        int user_id = Integer.parseInt(request.getParameter("user_id"));

        //采集用户输入的文章信息
        News news = new News();
        news.setTitle(request.getParameter("title"));
        news.setAuthorId(user_id);
        news.setNewsType(request.getParameter("news_type"));
        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        news.setCreateTime(dateTime);
        news.setUpdateTime("未更新");
        news.setContent(request.getParameter("news_content"));
        //创建时新闻flag为0
        news.setFlag(0);
        //创建业务逻辑对象并执行添加新闻操作
        NewsBiz newsBiz = new NewsBiz();
        newsBiz.add(news);

        //跳转到主页
        request.setAttribute("user_id",user_id);
        request.getRequestDispatcher("index.jsp").forward(request, response);

    }
}

