package ruanko.newspublish.action.news;

import ruanko.newspublish.biz.NewsBiz;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;

/**
 * 显示不同的栏目新闻
 * 直接点击各个类型，不需要选中栏目这个东西
 */
public class NewsShowType extends HttpServlet {


    private static final long serialVersionUID = -6747001677497186277L;

    /**
     * 只允许了get方式访问
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        String news_type = request.getParameter("news_type");
        //创建业务逻辑对象，取出该类型的文章
        NewsBiz newsBiz = new NewsBiz();
        List<News> newss = newsBiz.getType(news_type);

        //将取出的文章添加到request里，以便在跳转到jsp之后可以取出这些文章
        request.setAttribute("newss", newss);

        //跳转到显示新闻的列表页
        int user_id = Integer.parseInt(request.getParameter("user_id"));
        request.setAttribute("user_id",user_id);
        request.getRequestDispatcher("NewsShowType.jsp").forward(request, response);
    }
}

