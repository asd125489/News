package ruanko.newspublish.action.news;


import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.biz.NewsBiz;


/**
 * 删除新闻
 *
 */
public class NewsDelete extends HttpServlet {


    private static final long serialVersionUID = -5332420412538166813L;

    /**
     * 删新闻毕竟是一个危险操作，不能想删就删啊，所以用了post方式，给删除增加了一小点点难度
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //得到要删除新闻的no
        int news_no = Integer.parseInt(request.getParameter("news_no"));

        //创建业务逻辑对象，删除该新闻
        NewsBiz newsBiz = new NewsBiz();
        newsBiz.delete(news_no);

        //跳转到主页

        request.getRequestDispatcher("houtai.jsp").forward(request, response);

    }
}
