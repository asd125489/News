package ruanko.newspublish.action.news;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


/**
 * 显示 全部 新闻
 */
public class NewsShowAll extends HttpServlet {


    private static final long serialVersionUID = -2766292071044881773L;

    /**
     * 只允许了get方式访问
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        //创建业务逻辑对象，取出审核的新闻列表
        NewsBiz newsBiz = new NewsBiz();
        List<News> newss = newsBiz.getAll();

        //将取出的新闻添加到request里，以便在跳转到jsp之后可以取出
        request.setAttribute("newss", newss);

        //跳转到显示新闻的列表页
        request.getRequestDispatcher("NewsShowAll.jsp").forward(request, response);
    }
}
