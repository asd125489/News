package ruanko.newspublish.action.news;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;


/**
 * 返回主页面
 *
 */
public class Backtoindex extends HttpServlet {


    private static final long serialVersionUID = 629301594287003991L;

    /**
     * 只处理get方式<br>
     * 当用户浏览一个具体的新闻时，如果想分享给朋友，就需要将网址复制下来，发送给朋友，这时，网址中应当是包含新闻信息的，例如：新闻的id
     *
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int user_id = Integer.parseInt(request.getParameter("user_id"));
        //跳转到主页面
        request.setAttribute("user_id",user_id);
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }


}
