package ruanko.newspublish.action.news;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.entity.News;


/**
 * 执行真正的文章更新操作,指用户完成了编辑，点击保存后所执行的操作
 */
public class NewsUpdateDo extends HttpServlet {

    private static final long serialVersionUID = -5180657279295516989L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        //涉及用户输入信息的地方都要处理中文乱码问题
        //解决中文乱码问题，这取决于前台jsp页面上设置的编码格式
        request.setCharacterEncoding("utf8");

        //得到用户的id
        int news_no = Integer.parseInt(request.getParameter("news_no"));
        //采集用户输入的新闻
        News news = new News();
        news.setNo(Integer.parseInt(request.getParameter("news_no")));
        news.setTitle(request.getParameter("title"));
        news.setAuthorId(Integer.parseInt(request.getParameter("user_id")));
        news.setNewsType(request.getParameter("news_type"));
        news.setContent(request.getParameter("news_content"));
        news.setCreateTime(request.getParameter("create_time"));
        Date date = new Date();
        SimpleDateFormat df = new SimpleDateFormat("yyyy-MM-dd");//设置日期格式
        String dateTime = df.format(date); // Formats a Date into a date/time string.
        news.setUpdateTime(dateTime);

        news.setFlag(0);

        //创建业务逻辑对象，执行更新(修改)操作
        NewsBiz newsBiz = new NewsBiz();
        newsBiz.update(news);

        int user_id=Integer.parseInt(request.getParameter("user_id"));
        request.setAttribute("user_id",user_id);
        //跳转到主页
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}
