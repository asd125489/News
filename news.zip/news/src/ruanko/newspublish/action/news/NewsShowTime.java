package ruanko.newspublish.action.news;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;


/**
 * 显示最新新闻
 */
public class NewsShowTime extends HttpServlet {

    private static final long serialVersionUID = -2284789480781262969L;

    /**
     * 只允许了get方式访问
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        int user_id = Integer.parseInt(request.getParameter("user_id"));

        //创建业务逻辑对象，取出所有
        NewsBiz newsBiz = new NewsBiz();
        List<News> newss = newsBiz.getTime();

        //将取出的文章添加到request里，以便在跳转到jsp之后可以取出这些文章
        request.setAttribute("newss", newss);

        //跳转到显示新闻的列表页
        request.setAttribute("user_id",user_id);
        request.getRequestDispatcher("NewsShowTime.jsp").forward(request, response);
    }
}
