package ruanko.newspublish.action.news;


import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.entity.News;


/**
 * 显示热门新闻
 *
 */
public class NewsShowClick extends HttpServlet {

    private static final long serialVersionUID = -4952118158000873392L;

    /**
     * 只允许了get方式访问
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {


        //创建业务逻辑对象，取出热门文章
        NewsBiz newsBiz = new NewsBiz();
        List<News> newss = newsBiz.getClick();

        //将该新闻添加到request里，供jsp显示出来
        request.setAttribute("newss",newss);

        //跳转到热门新闻显示页面
        int user_id = Integer.parseInt(request.getParameter("user_id"));
        request.setAttribute("user_id",user_id);
        request.getRequestDispatcher("NewsShowClick.jsp").forward(request, response);

    }
}