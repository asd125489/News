package ruanko.newspublish.action.news;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;


/**
 * 显示我创建的新闻
 * */
public class NewsShowMy extends HttpServlet {


    private static final long serialVersionUID = 2178885101941319021L;

    /**
     * 只允许了get方式访问
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //得到网址中的用户id
        int user_id = Integer.parseInt(request.getParameter("user_id"));

        //创建业务逻辑对象，取出所有
        NewsBiz newsBiz = new NewsBiz();
        List<News> newss = newsBiz.getMynews(user_id);

        if(newss==null){
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter pw=response.getWriter();
            pw.print("<script language='javascript'>alert('您还没有创建新闻');window.location.href='index.jsp';</script>");
            //request.getRequestDispatcher("index.jsp").forward(request, response);
            /**
             * 显示的系统弹窗（不好看 是浏览器自带的弹窗）
             **/
        }else {
            //将该新闻添加到request里，供jsp显示出来
            request.setAttribute("newss",newss);
            //跳转到主页面
            request.setAttribute("user_id",user_id);
            request.getRequestDispatcher("NewsShowMy.jsp").forward(request, response);
        }

    }
}
