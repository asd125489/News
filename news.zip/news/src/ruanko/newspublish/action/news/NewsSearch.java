package ruanko.newspublish.action.news;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.entity.News;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

public class NewsSearch extends HttpServlet {

    private static final long serialVersionUID = 7357678559706352461L;

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        request.setCharacterEncoding("utf8");
        //得到要查询的关键字
        String keyword = request.getParameter("keyword");

        int user_id = Integer.parseInt(request.getParameter("user_id"));

        //创建业务逻辑对象，并使用关键字模糊查询
        NewsBiz newsBiz = new NewsBiz();
        List<News> newss = newsBiz.search(keyword);
        if(newss.size()==0){
            request.setAttribute("user_id",user_id);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }else {
            //将该新闻添加到request里，供jsp显示出来
            request.setAttribute("newss",newss);
            //跳转到页面
            request.setAttribute("user_id",user_id);
            request.getRequestDispatcher("NewsSearch.jsp").forward(request, response);
        }
    }
}

