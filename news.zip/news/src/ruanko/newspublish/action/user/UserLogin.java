package ruanko.newspublish.action.user;


import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.News;
import ruanko.newspublish.entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


/**
 * 用户登录
 *
 */
public class UserLogin extends HttpServlet {

    private static final long serialVersionUID = 3244049239846082589L;

    /**
     * 只处理post方式<br>
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf8");
        //输入用户账号密码
        String user_name = request.getParameter("user_name");
        String user_password = request.getParameter("user_password");
        User user=new User();
        user.setName(user_name);
        user.setPassword(user_password);


        //创建业务逻辑对象验证该用户是否正确，正确则登录
        UserBiz userBiz = new UserBiz();
        User user1 = userBiz.userLogin(user);

        if(user1==null){
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter pw=response.getWriter();
            pw.print("<script language='javascript'>alert('用户名或密码错误');window.location.href='userlogin.jsp';</script>");
            //request.getRequestDispatcher("login.jsp").forward(request, response);
            /**
             * 显示错误的系统弹窗（不好看 是浏览器自带的弹窗）
             **/
        }else {
            //跳转到主页面
            int user_id=user1.getId();
            request.setAttribute("user_id",user_id);
            request.getRequestDispatcher("index.jsp").forward(request, response);
        }
    }

}