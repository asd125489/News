package ruanko.newspublish.action.user;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.User;


/**
 * 要修改个人信息，首先要将信息显示给用户，这样才能修改，本类用于将个人信息显示给用户
 */
public class ChangeInfo extends HttpServlet {

    private static final long serialVersionUID = -5411743011402614303L;

    /**
     * 这里好像可以是post也可以是get没有太大的区别，不过为了简单起见，这里只处理了get方法
     */
    @Override
    public void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        //得到要修改的用户的id
        int user_id = Integer.parseInt(request.getParameter("user_id"));

        //创建业务逻辑对象，并取得该用户
        UserBiz userBiz = new UserBiz();
        User user=userBiz.get(user_id);

        //跳转到显示页面
        request.setAttribute("user",user);
        request.getRequestDispatcher("personal_information_update.jsp").forward(request, response);
    }
}

