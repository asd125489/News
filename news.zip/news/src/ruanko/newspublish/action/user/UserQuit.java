package ruanko.newspublish.action.user;


import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

/**
 * 用户退出，返回用户登录注册页面
 */
public class UserQuit extends HttpServlet {

    private static final long serialVersionUID = 5056979620075419702L;

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.getRequestDispatcher("userlogin.jsp").forward(request, response);
    }
}
