package ruanko.newspublish.action.user;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import ruanko.newspublish.action.AESUtil;
import ruanko.newspublish.biz.NewsBiz;
import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.User;


/**
 * 执行真正的个人信息修改操作,指用户完成了编辑，点击保存后所执行的操作
 */
public class ChangeInfoDo extends HttpServlet {

    private static final long serialVersionUID = -3323707008454398255L;

    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        AESUtil AES= new AESUtil();
        //涉及用户输入信息的地方都要处理中文乱码问题
        //解决中文乱码问题，这取决于前台jsp页面上设置的编码格式
        request.setCharacterEncoding("utf8");

        //采集用户输入的信息
        User user = new User();
        user.setId(Integer.parseInt(request.getParameter("user_id")));
        user.setName(request.getParameter("user_name"));
        //性别应该是勾选？
        user.setPassword(AES.encrypt( request.getParameter("user_password"),"adminadmin123456"));
        user.setAge(Integer.parseInt(request.getParameter("age")));
        user.setGender(request.getParameter("gender"));
        user.setSignature(request.getParameter("user_signature"));
        int user_id=user.getId();

        //创建业务逻辑对象，执行更新(修改)操作
        UserBiz userBiz = new UserBiz();
        userBiz.changeInfo(user);

        //跳转到主页
        request.setAttribute("user_id",user_id);
        request.getRequestDispatcher("index.jsp").forward(request, response);
    }
}

