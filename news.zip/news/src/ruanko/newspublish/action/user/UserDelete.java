package ruanko.newspublish.action.user;

import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;

public class UserDelete extends HttpServlet {

    private static final long serialVersionUID = 476873840622827770L;

    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        //得到用户id
        int user_id = Integer.parseInt(request.getParameter("user_id"));

        //创建业务逻辑对象，注销该用户
        UserBiz userBiz = new UserBiz();
        userBiz.userDelete(user_id);

        //跳转到主页
        request.getRequestDispatcher("houtai.jsp").forward(request, response);
    }
}
