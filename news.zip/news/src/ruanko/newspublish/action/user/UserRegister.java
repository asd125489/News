package ruanko.newspublish.action.user;

import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;

import ruanko.newspublish.biz.UserBiz;
import ruanko.newspublish.entity.User;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;


public class UserRegister extends HttpServlet {

    private static final long serialVersionUID = 8478252547980077045L;

    /**
     * 只处理post方式<br>
     */
    @Override
    public void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        request.setCharacterEncoding("utf8");
        //输入账号密码
        String user_name = request.getParameter("user_name");
        String user_password = request.getParameter("user_password");
        String gender=request.getParameter("gender");
        Integer age = Integer.valueOf(request.getParameter("age"));
        String signature=request.getParameter("user_signature");

        User user=new User();
        user.setName(user_name);
        user.setPassword(user_password);
        user.setGender(gender);
        user.setAge(age);
        user.setSignature(signature);
        //创建业务逻辑对象添加该用户
        UserBiz userBiz = new UserBiz();

        User user1=userBiz.Test(user);
        if(user1!=null){
            response.setContentType("text/html;charset=UTF-8");
            PrintWriter pw=response.getWriter();
            pw.print("<script language='javascript'>alert('该用户名已被占用，请更改名称');window.location.href='registered.jsp';</script>");
        }
        else{
            userBiz.userRegister(user);

            request.setAttribute("user", user);
            //跳转至主页面
            request.getRequestDispatcher("userlogin.jsp").forward(request, response);
        }

    }
}



